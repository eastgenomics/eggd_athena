
# THIS FILE IS GENERATED FROM SETUP.PY
version = '0.8.1'
__version__ = version